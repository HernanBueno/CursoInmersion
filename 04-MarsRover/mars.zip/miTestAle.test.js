const Limite = require("./limite");
const MarsRover = require("./mars");
const Ubicacion = require("./ubicacionAle");

test("parto del norte y giro a la derecha", ()=>{

    const r = new MarsRover(new Ubicacion(1,1,'n'));
    r.movilizar('r');
    expect(r.nombreOrientacion()).toEqual('e');

});

test("parto del norte y giro a la derecha", ()=>{

    const r = new MarsRover(new Ubicacion(1,1,'n'));
    r.movilizar('l');
    expect(r.nombreOrientacion()).toEqual('o');

});

test("parto del oeste y giro a la derecha", ()=>{

    const r = new MarsRover(new Ubicacion(1,1,'o'));
    r.movilizar('r');
    expect(r.nombreOrientacion()).toEqual('n');

});

test("parto del sur y giro a la derecha", ()=>{

    const r = new MarsRover(new Ubicacion(1,1,'s'));
    r.movilizar('r');
    expect(r.nombreOrientacion()).toEqual('o');

});

test("parto del este y giro a la derecha", ()=>{
    const r = new MarsRover(new Ubicacion(1,1,'e'));
    r.movilizar('r');
    expect(r.nombreOrientacion()).toEqual('s');

});

test("avanzo mirando al norte", ()=>{
    const limite =  new Limite(10,10);
    const ubicacion = new Ubicacion(1,1,'n',limite);
    const r = new MarsRover(ubicacion);
    r.movilizar('f');
    expect(r.ubicacionY()).toEqual(2);

});

test("avanzo mirando al este", ()=>{
    const limite =  new Limite(10,10);
    const ubicacion = new Ubicacion(1,1,'e',limite);
    const r = new MarsRover(ubicacion);
    r.movilizar('f');
    expect(r.ubicacionX()).toEqual(2);

});
test("retrocedo mirando al norte", ()=>{
    const limite =  new Limite(10,10);
    const ubicacion = new Ubicacion(1,2,'n',limite);
    const r = new MarsRover(ubicacion);
    r.movilizar('b');
    expect(r.ubicacionY()).toEqual(1);

});

test("retrocedo mirando al este", ()=>{
    const limite =  new Limite(10,10);
    const ubicacion = new Ubicacion(2,1,'e',limite);
    const r = new MarsRover(ubicacion);
    r.movilizar('b');
    expect(r.ubicacionX()).toEqual(1);

});

test("comando invalido", ()=>{
    const r = new MarsRover(new Ubicacion(1,2,'n'));
    
    expect(()=>r.movilizar('w')).toThrow(Error) ;

});


test("test que esta bien y pasa", ()=>{
    const limite =  new Limite(10,10);
    const ubicacion = new Ubicacion(1,2,'n',limite);
    const r = new MarsRover(ubicacion);
    r.movilizar('f');
    expect(r.ubicacionY()===3).toEqual(true);

});
test("Test que esta mal pero que pasa", ()=>{
    const limite =  new Limite(10,10);
    const ubicacion = new Ubicacion(1,2,'n',limite);
    const r = new MarsRover(ubicacion);
    r.movilizar('f');
    expect(r.ubicacion).toEqual(new Ubicacion(44,55,"r"));
});
//cambiar nombre de tests
test("Evaluar limite avanzando al este", ()=>{
    const limite =  new Limite(10,10);
    const ubicacion = new Ubicacion(9,1,'e',limite);
    const r = new MarsRover(ubicacion);
    r.movilizar('f');
   
    expect(r.ubicacionX()).toEqual(0);

});

test("Evaluar limite retrocediendo al este", ()=>{
    const limite =  new Limite(10,10);
    const ubicacion = new Ubicacion(0,1,'e',limite);
    const r = new MarsRover(ubicacion);
    r.movilizar('b');
    expect(r.ubicacionX()).toEqual(9);

});

test("Evaluar limite avanzando al norte", ()=>{
    const limite =  new Limite(10,10);
    const ubicacion = new Ubicacion(1,9,'n',limite);
    const r = new MarsRover(ubicacion);
    r.movilizar('f');
    expect(r.ubicacionY()).toEqual(0);

});
test("Evaluar limite retrocediendo al norte", ()=>{
    const limite =  new Limite(10,10);
    const ubicacion = new Ubicacion(1,0,'n',limite);
    const r = new MarsRover(ubicacion);
    r.movilizar('b');
    expect(r.ubicacionY()).toEqual(9);

});

